package com.enrique.usuarios.dao;

import java.util.ArrayList;
import java.util.List;

import com.enrique.usuarios.models.User;

public class FakeUserDao implements UserDao {

	private List<User> mockUserDB;
	
	public FakeUserDao() {
		// TODO Auto-generated constructor stub
		init();
	}
	
	private void init() {
		// TODO Auto-generated method stub
		mockUserDB = new ArrayList<User>();
		User user = new User(1, "Enrique", "Enrique2104", "Apple Inc");
		User user2 = new User(2, "Mariana", "Mariana1101", "Microsoft CEO");
		User user3 = new User(3, "Luz", "Luz0412", "Facebook CEO");
		
		mockUserDB.add(user);
		mockUserDB.add(user2);
		mockUserDB.add(user3);
	}
	@Override
	public int create(User user) {
		// TODO Auto-generated method stub
		user.setId(mockUserDB.size()+1);
		mockUserDB.add(user);
		return user.getId();
	}

	@Override
	public User selectById(Integer id) {
		// TODO Auto-generated method stub
		List<User> users = selectAll();
		User user = null;
		for (User u : users) {
			if (u.getId().equals(id)) {
				user = u;
			}
		}
		return user;
	}

	@Override
	public List<User> selectAll() {
		return mockUserDB;
	}

	@Override
	public void delete(Integer id) {
		List<User> users = selectAll();
		User result = null;
		for (User user : users) {
			if (user.getId().equals(id)) {
				users.remove(user);
				break;
			}
		}
	}

	@Override
	public void update(Integer id, User user) {
		List<User> users = selectAll();
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i).getId().equals(id)) {
				users.set(i, user);
			}
		}
	}

}
