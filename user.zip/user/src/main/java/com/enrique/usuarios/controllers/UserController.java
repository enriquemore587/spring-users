package com.enrique.usuarios.controllers;

import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.enrique.usuarios.dao.FakeUserDao;
import com.enrique.usuarios.dao.UserDao;
import com.enrique.usuarios.models.User;

@Controller
public class UserController {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class); 
	
	@Autowired
	private UserDao userDao;
	
	@RequestMapping(method =  RequestMethod.GET, value = "/users")
	public String showUsers(Map<String, Object> model){
		
		LOGGER.info("PRODUCT SHOW USERS. ");
		
		List<User> users = userDao.selectAll();
		
		model.put("users", users);
		
		return "users";
	}
	
	@RequestMapping(method= RequestMethod.GET, value= "/users/{id}")
	public String userDetail(@PathVariable(value= "id") Integer id, Map<String, Object> model){
		LOGGER.info("USER DETAIL" + id);
		
		User user = userDao.selectById(id);
		
		model.put("user", user);
		
		return "userDetail";
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/users/new")
	public String newUser(Map<String, Object> model){
		
		LOGGER.info("Showing custom view to insert by GET");
		
		model.put("user", new User());
		
		return "newUser";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/users/new")
	public ModelAndView createUser(@ModelAttribute("user")User user){
		LOGGER.info("Saveview POST: "+ user.getDescripcion());
		
		ModelAndView modelAndView = new ModelAndView();
		
		if (userDao.create(user)>0) {
			
			modelAndView.setViewName("created");
			
			modelAndView.addObject("user",user);
			
		}else{
			modelAndView.setViewName("error");
			modelAndView.addObject("error", "An error ocurred while trying to create a new user. Please, try again");
		}
		return modelAndView;
	}
	
	@RequestMapping(value = "/users/update/{id}", method = RequestMethod.GET)
	public String update(@PathVariable(value="id")Integer id, Model model){
		
		LOGGER.info("Showing update view GET. . .");
		
		model.addAttribute("user", userDao.selectById(id));
		
		return "update";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/users/saveupdate")
	public ModelAndView saveUpdate(User user){
		
		LOGGER.info("Save update: "+ user.getId());
		
		ModelAndView modelAndView = new ModelAndView();
		
		userDao.update(user.getId(), user);
		
		modelAndView.addObject("user", user);
		
		modelAndView.setViewName("saveUpdated");
		
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/users/delete/{id}")
	public String delete(@PathVariable(value="id") Integer id, Model model){
		
		LOGGER.info("Product detail / delete");
		
		userDao.delete(id);
		
		model.addAttribute("userid", id);
		
		return "deleted";
	}
}
